#include "iostream"
#include "Grafo.hpp"

using namespace std;

void main() 
{
	//Crear el grafo
	CGrafo<int>* G = new CGrafo<int>();

	//Agregar V�rtices
	G->adicionarVertice(2); //indice=0
	G->adicionarVertice(15); //indice=1
	G->adicionarVertice(30); //indice=2
	G->adicionarVertice(7); //indice=3

	//Agregar los arcos
	G->adicionarArco(0, 1); //indice=0
	G->modificarArco(0, 0, 10);
	G->adicionarArco(0, 3);//indice=1
	G->modificarArco(0, 1, 20);
	G->adicionarArco(1, 2);//indice=0
	G->modificarArco(1, 0, 30);
	G->adicionarArco(2, 0);//indice=0
	G->modificarArco(2, 0, 40);
	//cout<<" ---> "<<G->obtenerVerticeLlegada(0, 0)<<endl; //Muestra v�rtice 1
	//cout<<" ---> "<<G->obtenerVerticeLlegada(0, 1)<<endl; //Muestra v�rtice 3
	//G->adicionarArco(3, 0);//indice=0
	//G->modificarArco(3, 0, 55);

	//Imprimir los v�rtices con sus arcos
	for (int i = 0; i < G->cantidadVertices(); ++i) 
	{
		cout << "Vertice : " << G->obtenerVertice(i)<<endl;
		for (int j = 0; j < G->cantidadArcos(i); j++)
		{
			cout << "Arco->" << G->obtenerArco(i, j) << " ";
		}
		cout << endl;
	}
	system("pause");
}